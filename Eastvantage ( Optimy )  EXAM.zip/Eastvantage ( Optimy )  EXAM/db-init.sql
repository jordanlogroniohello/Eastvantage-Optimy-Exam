CREATE DATABASE exam;
USE exam;
CREATE TABLE blog (
  `id` INT(6) AUTO_INCREMENT PRIMARY KEY,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `type` enum('Government','Food','Sports','Places') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
);
