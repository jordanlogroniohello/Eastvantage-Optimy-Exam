<?php

namespace Src\core;

class Database{

	private $host   = 'localhost';
	private $dbname = 'exam';
	private $user   = 'root';
	private $pass   = '';
	public $conn ;


	public function __construct()
	{
		$this->connect();	
	}

	private function connect() 
	{
		try {
			$db = @mysqli_connect($this->host,$this->user,$this->pass,$this->dbname);

			if (!$db) {
				die("Failed to connect to MySQL ");
			}

			$this->conn = $db;

		} catch (Exception $e) {
			die($e->errorMessage());
	    }
	}
	
	



}

?>