<?php
namespace Src\core;
require_once 'database.php';

use Src\core\Database;

class Model{

	public $table_name;
	public $primary;
	public $fields = [];
			
	public $conn;

	public function __construct(){
		$db = new Database();
		$this->conn = $db->conn;
	}

	public function query($query)
	{
		return mysqli_query($this->conn, $query);
	}

	public function fetchAssoc($res)
	{
		$data = [];
		while ($row = mysqli_fetch_assoc($res)) {
			$data[] = $row;
		}

		return $data;
	}

	public function closeConnection()
	{	
		if($this->conn)
			mysqli_close($this->conn);
	}

	public function populate($data){
		foreach ($data as $key => $value) {
			$this[$key] = $value;
		}
	}


}



?>