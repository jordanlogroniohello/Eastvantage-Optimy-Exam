<?php
namespace Src\models;

require_once 'core/model.php';

use Src\core\Model;

class Blog extends Model{

	public $table_name = "Blog";
	public $primary    = "id";
	public $fields     = ['id','title','content','filename','type','create_at'];

	public $id;
	public $title;
	public $filename;
	public $type;
	public $create_at;

	public function __construct(){
		parent::__construct();
	}


}




?>