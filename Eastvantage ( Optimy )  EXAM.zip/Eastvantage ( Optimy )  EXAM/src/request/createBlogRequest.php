<?php

require_once 'models/Blog.php';
use Src\models\Blog;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = '';
    if (is_array($_FILES)) {
        move_uploaded_file(
            $_FILES['file']['tmp_name'],
            __DIR__.'/uploads/'.$_FILES['file']['name']
        );
        $filename = $_FILES['file']['name'];
    }

    $blog = new Blog();

    $sql = '
        INSERT INTO blog SET
            title = "'.mysqli_real_escape_string($blog->conn,$_POST['title']).'",
            content = "'.mysqli_real_escape_string($blog->conn,$_POST['content']).'",
            type = "'.mysqli_real_escape_string($blog->conn,$_POST['type']).'",
            filename = "'.mysqli_real_escape_string($blog->conn,$filename).'",
            created_at = NOW()
    ';

    
    $blog->query($sql);
    $blog->closeConnection();
    header('Location: index.php');
}

?>