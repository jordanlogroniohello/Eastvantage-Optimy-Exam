<?php
require_once 'models/Blog.php';
use Src\models\Blog;

$blog = new Blog();

$sql = "SELECT * FROM blog ORDER BY created_at DESC;";

if(isset($_GET['filter'])){
    if (trim($_GET['filter']) !== '') {
        $sql = 'SELECT * FROM blog WHERE type="'.$_GET['filter'].'" ORDER BY created_at DESC;';
    }
}

$res   = $blog->query($sql);
$blogs = $blog->fetchAssoc($res);
$blog->closeConnection();

?>