<?php
require_once 'request/createBlogRequest.php';
?>


<?php require_once 'header.php'; ?>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">Article</a>
            <a class="navbar-brand" href="create-news.php">Create Article</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mt-2 mx-auto">

                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="newsTitle">Title</label>
                        <input type="text" class="form-control" id="newsTitle" placeholder="Awesome Title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="newContent">Content</label>
                        <textarea class="form-control" id="newContent" rows="15" name="content" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="newContent">Content Type</label>
                        <select class="form-control" id="contentType" name="type" required>
                            <option value="">Choose Type</option>
                            <option>Government</option>
                            <option>Food</option>
                            <option>Sports</option>
                            <option>Places</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <div class="custom-file">
                            <input type="file" id="validatedCustomFile" name="file" required>
                            <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a class="btn btn-outline-danger" href="index.php">Cancel</a>
                </form>
            </div>
        </div>
    </div>

</body>


<?php require_once 'footer.php'; ?>
