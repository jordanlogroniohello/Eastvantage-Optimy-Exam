<?php
require_once 'request/indexBlogRequest.php';
?>

<?php require_once 'header.php'; ?>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">Articles</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
            </button>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php?filter=government">Government</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?filter=sports">Sports</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?filter=food">Food</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link btn btn-success" href="create-news.php">Create</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row text-center">
            <?php if (empty($blogs)) : ?>
                <header class="jumbotron mt-4 mx-auto mb-12">
                    <h1 class="display-3">Oops no entry for this type!</h1>
                    <a class="btn btn-primary btn-lg mt-4" href="create-news.php">Create Article</a>
                </header>
            <?php endif; ?>
            <?php foreach ($blogs as $blog) : ?>
            <div class="col-lg-3 col-md-6 mb-4 mt-2">
                <div class="card h-100">

                    <?php if ($blog['filename']) : ?>
                    <img class="card-img-top" src="uploads/<?=$blog['filename']?>" alt="">
                    <?php endif; ?>

                    <div class="card-body">
                        <h4 class="card-title"><?=$blog['title']?></h4>
                        <p class="card-text" style="text-overflow:ellipsis; max-height: 200px; overflow:hidden"><?=$blog['content']?></p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="btn btn-primary">Find Out More!</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>


    
</body>


<?php require_once 'footer.php'; ?>
